package finalClustering;
public class Pm {
	 
    public double p1=0;
    public double p2=0;
    public double p3=0;
    private int cluster_number=0;
 
    public Pm(double p1, double p2,double p3){
     this.setP1(p1);
     this.setP2(p2);
     this.setP3(p3);
    }
    
	double getP1() {
		return p1;
	}
	void setP1(double p1) {
		this.p1 = p1;
	}
	double getP2() {
		return p2;
	}
	void setP2(double p2) {
		this.p2 = p2;
	}
	double getP3() {
		return p3;
	}
	void setP3(double p3) {
		this.p3 = p3;
	}
	public void setCluster(int n) {
        this.cluster_number = n;
    }
    
    //Calcule la distance entre 2 PM(distance euclidienne)
    public static double distance(Pm p1, Pm centre) {
        return Math.sqrt(Math.pow((centre.getP1()-p1.getP1()), 2) 
        		+ Math.pow((centre.getP2()-p1.getP2()), 2)
        		+ Math.pow((centre.getP3()-p1.getP3()), 2));
    }
    
    public String toString(){
    	return "\""+p1+","+p2+","+p3+"\"";
    }
}