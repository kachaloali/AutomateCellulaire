package finalClustering;

import java.util.ArrayList;
public class convertIntoNewick {
	String Newick="(";
	String Newick1="(";
	
	ArrayList<Cluster>  delfirst(ArrayList<Cluster> subclusters){
		ArrayList<Cluster>  subclust0 = new ArrayList<Cluster> ();
		assert (subclusters.size()>=1);
		for (int i=1; i<subclusters.size(); i++) subclust0.add(subclusters.get(i));
		return subclust0;
	}
	
	Cluster delfirst(Cluster clust){
		Cluster clust0 = new Cluster(0);
		assert (clust.clustersPM.size()>=1);
		for (int i=1; i<clust.clustersPM.size(); i++)
			{
				clust0.clustersPM.add(clust.clustersPM.get(i));
			}
		return clust0;
		
	}
	
	String getNewickIntermediate(Cluster cluster ){
		if (cluster.clustersPM.size()==1){
			this.Newick+=cluster.clustersPM.get(0).toString()+")";
		}else if (cluster.clustersPM.size()>0){
			this.Newick+=cluster.clustersPM.get(0).toString()+", ";
			this.getNewickIntermediate(delfirst(cluster));			
		}
	
		return this.Newick;
	}
	
	public String getNewick(ArrayList<Cluster> subcluster ){
		if(subcluster.get(0).clustersPM.size()>0){
			if (subcluster.size()==1){;
				this.Newick1+=getNewickIntermediate(subcluster.get(0))+");";
			}else if (subcluster.size()>0){
				this.Newick1+=getNewickIntermediate(subcluster.get(0))+" ,";
				ArrayList<Cluster> scluster=this.delfirst(subcluster);
				if(scluster.get(0).clustersPM.size()>0){
					this.Newick="(";
					this.getNewick(scluster);
				}else{
					System.out.println("alors");
					return this.Newick1=this.Newick1.substring(0, this.Newick1.length()-2)+";";
				}
				
			}	
		}
		return this.Newick1;
	}
	public static void main(String[] args) {
		
	}
}
