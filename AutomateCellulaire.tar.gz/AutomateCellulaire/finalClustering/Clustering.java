package finalClustering;
import java.util.ArrayList;

public class Clustering {
    private int k= 10;       
    public ArrayList<Pm> clustersPM;
    public ArrayList<Cluster> clusters;   
    public Clustering() {
    	this.clustersPM = new ArrayList<Pm>();
    	this.clusters = new ArrayList<Cluster>();    	
    }
	private void plotClusters() {
    	for (int i = 0; i < k; i++) {
			Cluster c = clusters.get(i);
			c.plotCluster();
    	}
    }
    /**
     * cette méthode permet de calculer les k clusters 
     */
    public void calculate() {
        boolean test = false;
        int nbIteration = 0;
        while(!test){
        	//on efface les PM des clusters
        	this.clearClustersPM();
        	/*on recupère tous les centres des clusters*/
        	ArrayList<Pm> lastCenters = getCenters();       	
        	//on assigne les PM au cluster le pus proche d'elles
        	this.assignCluster();
            //Calcule nouveau centre pour chaque cluster.
        	this.calculateCenters();
        	nbIteration++;
        	ArrayList<Pm> currentCenters = getCenters();
        	/*on calcule la distance total entre les anciens et les nouveau centres
        	 * cette ditance est celle qu'on voudrai minimiser au plus possible
        	 */
        	double distance = 0;
        	for(int i = 0; i< lastCenters.size(); i++) {
        		distance += Pm.distance(lastCenters.get(i),currentCenters.get(i));
        	}
        	        	
        	if(distance == 0){
        		test = true;
        	}
        }
    	System.out.println("---------------------------------------------------------------");
    	System.out.println("Iteration: " + nbIteration);
    	plotClusters();
    	
    }
    /**
     * cette méthode efface toutes les PM de chaque cluster
     */
    private void clearClustersPM() {
    	for(Cluster cluster : this.clusters) {
    		cluster.clearPM();
    	}
    }
    /**
     * cette méthode renvoie tous les centres desclusters
     */
    private ArrayList<Pm> getCenters() {
    	ArrayList<Pm> centre = new ArrayList<Pm>(k);
    	for(Cluster cluster : this.clusters) {
    		centre.add(cluster.getCenter());
    	}
    	return centre;
    }
    /**
     * cette méthode permet d'assigner une PM au cluster qui a le centre le plus proche d'elle
     * on parcourt tous les clusters pour cherher la petite distance
     */
    private void assignCluster() {
        double max = Double.MAX_VALUE;
        double min = max; 
        int numCluster = 0;                 
        double distance = 0.0; 
        
        for(Pm pm : this.clustersPM) {
        	min = max;
            for(int i = 0; i< k; i++) {
            	Cluster c = clusters.get(i);
                distance = Pm.distance(pm, c.getCenter());
                if(distance < min){
                    min = distance;
                    numCluster = i;
                }
            }
            pm.setCluster(numCluster);
            clusters.get(numCluster).addPM(pm);
        }
    }
    /**
     *cette méthode permet de recalculer les centres clusters
     */
    private void calculateCenters() {
        for(Cluster cluster : clusters) {
            double sumP1 = 0,sumP2 = 0,sumP3 = 0;
            ArrayList<Pm> pmList = cluster.getClustersPM();
            int n_pm = pmList.size();
            //on fait la somme totale par PM
            for(Pm pm : pmList) {
            	sumP1 += pm.getP1();
                sumP2+= pm.getP2();
                sumP3+=pm.getP3();
            }            
            
            if(n_pm > 0) {//on évite la division par 0
            	double newP1 = sumP1 / n_pm;
            	double newP2 = sumP2 / n_pm;
            	double newP3 =sumP3 / n_pm;
            	cluster.getCenter().setP1(newP1);
            	cluster.getCenter().setP2(newP2);
            	cluster.getCenter().setP3(newP3);
            }
        }
    }

   
    public int getK() {
		return k;
	}
	public void setK(int nb) {
		k = nb;
	}
	public ArrayList<Pm> getClustersPM() {
		return clustersPM;
	}
	public void setClustersPM(ArrayList<Pm> clustersPM) {
		this.clustersPM = clustersPM;
	}
	public ArrayList<Cluster> getClusters() {
		return clusters;
	}
	public void setClusters(ArrayList<Cluster> clusters) {
		this.clusters = clusters;
	}   
}