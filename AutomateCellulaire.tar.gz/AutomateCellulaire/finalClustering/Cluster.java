package finalClustering;

import java.util.ArrayList; 
public class Cluster {
	public int NumCluster;
	public ArrayList<Pm> clustersPM;
	public Pm center;
	
	
	public Cluster(int num) {
		this.NumCluster= num;
		this.clustersPM = new ArrayList<Pm>();
		this.center = null;
	}

	public void clearPM() {
		this.clustersPM.clear();
	}
	
	public void plotCluster() {
		System.out.println("[Cluster No: " +this.NumCluster+": "+this.clustersPM.size()+" cellules]");
		System.out.println("[Centre: " + center + "]"); 
		System.out.println("les PM: \n(");
		for(Pm pm : this.clustersPM) {
			System.out.println(pm);
		}
		System.out.println(")");
	}
 
	
	public ArrayList<Pm> getClustersPM() {
		return clustersPM;
	}	
	public void addPM(Pm pm) {
		this.clustersPM.add(pm);
	}
	Pm getCenter() {
		return center;
	}
	public void setCentre(Pm centre) {
		this.center = centre;
	}
	int getNumCluster() {
		return NumCluster;
	}
	void setNumCluster(int numCluster) {
		NumCluster = numCluster;
	}
	void setClustersPM(ArrayList<Pm> clustersPM) {
		this.clustersPM = clustersPM;
	}
}