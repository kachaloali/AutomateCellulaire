package testUnit;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import finalClustering.Pm;
import finalProject.Cellule;
import finalProject.Generation;
import finalProject.Univers;

public class test{
	@Test
	public void testdistance() throws Exception {
		////////////////////////////////////////////////////////////////////////////////////////////////
		double a=2,b=3,c=4,d=3,e=4,f=5;
		Pm mp1=new Pm(a,b,c);
		Pm mp2=new Pm(d,e,f);
		double distance=Math.sqrt(Math.pow(a-d, 2)+Math.pow(b-e, 2)+Math.pow(c-f, 2));
		assertTrue("Calcule distance en pane!",Pm.distance(mp1, mp2)==distance);
		/////////////////////////////////////////////////////////////////////////////////////////////////
		
		/////////////////////////////////////////////////////////////////////////////////////////////////
		/* test constructeur cellule*/
		double averageCoutDeplacement=1;
		double stdDevcoutDeplacement=2;
		double averageLifeExpectancy=3;
		double stdDevLifeExpectancy=4;
		double[] PM=new double[3];
		PM[0]=0.5;PM[1]=0.4;PM[2]=0.1;
		double lifeExpectancy=6;
		int abscisse=7;
		int ordonnee=8;
		int age=0;
		int z=0;
		int type=1;
		Cellule cell=new Cellule(abscisse,ordonnee,averageLifeExpectancy,stdDevLifeExpectancy,
			averageCoutDeplacement,stdDevcoutDeplacement);
		assertTrue("Erreur au niveau d'abscisse et ordonnee!",(cell.abscisse==abscisse && cell.ordonnee==ordonnee));
		assertTrue("Erreur Moyenne cout deplacement!",cell.averageCoutDeplacement==averageCoutDeplacement);
		assertTrue("Erreur E-Type cout deplacement!",cell.stdDevcoutDeplacement==stdDevcoutDeplacement);
		assertTrue("Erreur Moyenne Esperance de vie!",cell.averageLifeExpectancy==averageLifeExpectancy);
		assertTrue("Erreur E-Type Esperance de vie!",cell.stdDevLifeExpectancy==stdDevLifeExpectancy);
		assertTrue("Erreur Proba de deplacement!",(cell.PM[0]==PM[0] && cell.PM[1]==PM[1] && cell.PM[1]==PM[1]));
		assertTrue("Erreur Esperance de vie!",cell.lifeExpectancy>=0);
		//assertTrue("Erreur cout de deplacement!",cell.coutDeplacement>=0);
		assertTrue("Erreur Couleur!",cell.couleur==1 || cell.couleur==2 || cell.couleur==0);
		assertTrue("Erreur Age!",cell.age==age);
		assertTrue("Erreur Orientation!",cell.orientation>=0 && cell.orientation<=3);
		assertTrue("Erreur Z!",cell.z==z);
		assertTrue("Erreur Etat!",cell.etat==0);
		assertTrue("Erreur Type!",cell.type==type);
		assertTrue("Erreur Energie!",cell.energie>=0);
		assertTrue("Erreur Rapidité!",(cell.rapidite==0 || cell.rapidite==1 || cell.rapidite==2));
		
		
		
		
		////////////////////////////////////////////////////////////////////////////////
		/*test univers*/
		
		int dimension=10;
		double pcellule=0.1;
		double pvirus=0.2;
		double penergie=0.3;
		Univers u=new Univers(dimension, pcellule,pvirus,penergie);
		assertTrue("Erreur pcellule Univers!",u.pcellule==pcellule);
		assertTrue("Erreur panneau Univers!",u.pan!=null);
		assertTrue("Erreur panneau nourriture Univers!",u.pn!=null);
		assertTrue("Erreur Dimension Univers!",u.dimension==dimension);
		assertTrue("Erreur cMatrice Univers!",u.cMatrice!=null);
		assertTrue("Erreur matNourriture Univers!",u.matNourriture!=null);
		
		
		
		
	}
}
