package finalProject;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

public class ControlSpace extends JPanel implements ActionListener{
	private static final long serialVersionUID = 1L;
	Univers univ;
	private Border border;
	private TitledBorder titledBorder;
	private JButton go = new JButton("start");
	private JButton stop = new JButton("stop");
	private JButton generer = new JButton("generate");
	private JButton clear = new JButton("clear");
	private JButton next = new JButton("next");
	private JButton prev = new JButton("prev.");
	private JButton quiet = new JButton("quitter");
	private JButton PM = new JButton("PM");
	private JLabel x=new JLabel("Abs:");
	private JLabel y=new JLabel("Ord:");
    private JLabel renew=new JLabel("renew ?:");
    private JLabel Lyes=new JLabel("yes:");
    private JLabel Lno=new JLabel("no:");
    private JLabel cluster=new JLabel("cluster ?:");
    private JLabel numberOfCluster=new JLabel("nb:");
    private JTextField tx=new JTextField();
    private JTextField ty=new JTextField();
    JTextField tcluster=new JTextField();
    JTextField tnumberOfCluster=new JTextField();
    private ButtonGroup bg = new ButtonGroup();
    protected JRadioButton yes= new JRadioButton();
    protected JRadioButton no= new JRadioButton();
    private JLabel P1=new JLabel("");
    private JLabel P2=new JLabel("");
    private JLabel P3=new JLabel("");
    private JLabel P4=new JLabel("");
    private JLabel P5=new JLabel("");
    protected boolean animated=false;
    private Thread t;
    int numGeneration,numberOfClusters;
	ControlSpace(Univers univ) throws Exception{
		this.univ=univ;
		this.Espc();
	}
    private void Espc() throws Exception {
	    /*reglage de l'espace de controle => titre de bord, background, et la dimmension*/
		border = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(120, 134, 134));
	    titledBorder = new TitledBorder(border,"Espace Controle");
	    this.setBackground(Color.lightGray);
	    this.setBorder(titledBorder);
	    this.setBounds(new Rectangle(univ.getDimension(), 5, 180, 135));
	    this.setLayout(null);
	    /*on gère le positionnement des boutons & labels*/
	    generer.setBounds(new Rectangle(univ.getDimension()-25, 20, 100, 38));
	    clear.setBounds(new Rectangle(univ.getDimension()+82, 20, 87, 38));
	    next.setBounds(new Rectangle(univ.getDimension()-25, 70, 100, 38));
	    prev.setBounds(new Rectangle(univ.getDimension()+82, 70, 87, 38));
	    quiet.setBounds(new Rectangle(univ.getDimension()-25,410,193,38));
	    go.setBounds(new Rectangle(univ.getDimension()+10, 113, 132, 40));
	    stop.setBounds(new Rectangle(univ.getDimension()+10, 160, 132, 38)); 
	    PM.setBounds(new Rectangle(univ.getDimension()-25, 205, 100, 38)); 
	    x.setBounds(new Rectangle(univ.getDimension()+90, 164, 70, 100));
	    tx.setBounds(new Rectangle(univ.getDimension()+125, 207, 25, 17));
	    y.setBounds(new Rectangle(univ.getDimension()+90, 184, 70, 100));
	    ty.setBounds(new Rectangle(univ.getDimension()+125, 227, 25, 17));
	    renew.setBounds(new Rectangle(univ.getDimension()-20, 255, 70, 17));
	    Lyes.setBounds(new Rectangle(univ.getDimension()+48, 255, 70, 17));
	    Lno.setBounds(new Rectangle(univ.getDimension()+105, 255, 70, 17));
	    yes.setBounds(new Rectangle(univ.getDimension()+80, 255, 20, 17));
	    no.setBounds(new Rectangle(univ.getDimension()+129, 255, 20, 17));
	    bg.add(yes);bg.add(no);
	    cluster.setBounds(new Rectangle(univ.getDimension()-20, 275, 75, 17));
	    tcluster.setBounds(new Rectangle(univ.getDimension()+50, 275, 25, 17));
	    numberOfCluster.setBounds(new Rectangle(univ.getDimension()+90, 275, 35, 17));
	    tnumberOfCluster.setBounds(new Rectangle(univ.getDimension()+125, 275, 25, 17));
	    P1.setBounds(new Rectangle(univ.getDimension(), 264, 150, 100));
	    P2.setBounds(new Rectangle(univ.getDimension(), 330, 150, 17));
	    P3.setBounds(new Rectangle(univ.getDimension(), 355, 150, 17));
	    P4.setBounds(new Rectangle(univ.getDimension()-20, 320, 150, 50));
	    P5.setBounds(new Rectangle(univ.getDimension()-20, 340, 150, 50));
	    /*on ajoute les bouttons & labels à l'espace controle*/
	    this.add(clear, null);
	    this.add(generer, null);
	    this.add(go, null);
	    this.add(stop, null);
	    this.add(next, null);
	    this.add(prev, null);
	    this.add(quiet, null);
	    this.add(PM, null);
	    this.add(x, null);
	    this.add(tx, null);
	    this.add(y, null);
	    this.add(ty, null);
	    this.add(renew);
	    this.add(Lyes,null);
	    this.add(Lno);
	    this.add(yes, null);
	    this.add(no, null);
	    this.add(cluster);
	    this.add(tcluster);
	    this.add(numberOfCluster);
	    this.add(tnumberOfCluster);
	    this.no.setSelected(true);
	    this.add(P1, null);
	    this.add(P2, null);
	    this.add(P3, null);
	    this.add(P4, null);
	    this.add(P5, null);
	  /*on ajoute les écouteurs d'evenements*/
	    go.addActionListener(new GoListener());
	    stop.addActionListener(new StopListener());
	    generer.addActionListener(univ);
	    clear.addActionListener(univ);
	    next.addActionListener(univ);
	    prev.addActionListener(univ);
	    quiet.addActionListener(univ);
	    PM.addActionListener(univ);
	}
	
    /**
	 * Gestion des evenements
	 */
	public void actionPerformed(ActionEvent arg0) {
		/* recherche des PM d'une cellule*/
		if(arg0.getSource() == PM){
			if ((tx.getText().equalsIgnoreCase("") || ty.getText().equalsIgnoreCase(""))){
				System.out.println("Veuillez saisir les coordonnées de la cellule!");
			}else{
				int i=(int) Double.parseDouble(tx.getText());
				int j=(int) Double.parseDouble(ty.getText());
				if (i>=0 && i<univ.dimension && j>=0 && j<univ.dimension){
					if (univ.getcMatrice()[i][j]!=null){
						Cellule cellule= (Cellule)univ.getcMatrice()[i][j];
						this.P1.setText("P1 :"+String.valueOf(cellule.PM[0]));
						this.P2.setText("P2 :"+String.valueOf(cellule.PM[1]));
						this.P3.setText("P3 :"+String.valueOf(cellule.PM[2]));
						this.P4.setText("");this.P5.setText("");
					}else{
						this.P1.setText("");
						this.P2.setText("");
						this.P3.setText("");
						this.P4.setText("the box is null or");
						this.P5.setText("incorrect coordinates!");
					}
				}else{
					System.out.println("Vous avez depassez la taille de l'univers!");
					System.out.println("les coordonnées sont dans l'intervalle: [0,"+univ.dimension+"[");
				}
			}
		}/*bouttons generate*/
		else if (arg0.getSource()==generer){
			univ.setcMatrice(univ.univCellule(univ.dimension, univ.pcellule));
			univ.pan.repaint();
			univ.matNourriture =univ.Environnement(univ.dimension,univ.penergie, univ.pvirus);
			univ.previouscMatrice=univ.cMatrice;
		}/*bouttons next*/
		else if (arg0.getSource()==next){
			//this.nextcMatrice=update();
			if(univ.hasCellule()){
				univ.previouscMatrice=univ.cMatrice;
				univ.cMatrice=univ.update();	
				//this.nextcMatrice=update();
				univ.pan.repaint();
				
			}else System.out.println("l'univers est vide!");
			
		}/*bouttons previous*/
		else if (arg0.getSource()==prev){
			if (univ.hasCellule()){
				univ.nextcMatrice=univ.cMatrice;
				univ.cMatrice=univ.previouscMatrice;
				univ.previouscMatrice=new Cellule[univ.getDimension()][univ.getDimension()];
				univ.pan.repaint();
			}else System.out.println("l'univers est null!");	
		}/*bouttons clear*/
		else if (arg0.getSource()==clear){
			univ.cMatrice=new Cellule[univ.dimension][univ.dimension];
			univ.previouscMatrice=univ.cMatrice;
			univ.nextcMatrice=univ.update();
			univ.pan.repaint();
		}/*bouttons quitter*/
		else {
			try {
				univ.gn.ftcell.close();
				univ.gn.ftEnergie.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			 System.exit(0);
		}	
	}
	/*construit une sous-classe qui demare le jeu, le boutton "start" écoute cette classe*/
	class GoListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			animated=true;
			t = new Thread(new PlayJeu());/*on construit un thread pour controler l'animaation*/
			t.start();
			go.setEnabled(false);
			clear.setEnabled(false);
			stop.setEnabled(true);
		} 
	}
	/*construit une sous-classe qui met en pause le jeu, le boutton "stop" écoute cette classe*/
    class StopListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			animated=false;
			go.setEnabled(true);
			clear.setEnabled(true);
			stop.setEnabled(false);
		} 
	}
	class PlayJeu implements Runnable{
		public void run() {
			try {
				univ.deplacement();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
