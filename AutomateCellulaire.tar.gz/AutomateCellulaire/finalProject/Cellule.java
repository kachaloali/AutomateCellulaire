package finalProject;
import java.util.ArrayList;
import java.util.Random;
public class Cellule {
	/**
	 * les paramètres de la cellule
	 */
	public double averageCoutDeplacement;
	public double stdDevcoutDeplacement;
	public double averageLifeExpectancy;
	public double stdDevLifeExpectancy;
	public double[] PM=new double[3];
	public double coutDeplacement;
	public double lifeExpectancy;
	public int seuilAbondance=150;
	public int seuilStadeMort=50;
	public int seuilClonage=200;
	public double energie;
	public int orientation;
	public int rapidite;
	public int abscisse;
	public int ordonnee;
	/**couleur:
	 * 2=orange (cellule deplaçant plus vite), 
	 * 1=verte (cellule deplaçant plus normalement), 
	 * 0=grise (cellule deplaçant lentement => cellule mourante)
	 */
	public int couleur=1;
	public int etat=0;//0=non attaquée, 1=attaquée par un virus.
	public int age=0;
	public int z=0;
	public int type=1;
	
	/**
	 * Constructeur de la cellule
	 */
	public Cellule(int abs, int odr,double averageLifeExpectancy, double stdDevLifeExpectancy,
		double averageCoutDeplacement, double stdDevcoutDeplacement){
		this.setAbscisse(abs);
		this.setOrdonnee(odr);
		this.PM[0]=0.5;
		this.PM[1]=0.4;
		this.PM[2]=0.1;
		this.setZ(0);
		this.averageLifeExpectancy=averageLifeExpectancy;
		this.stdDevLifeExpectancy=stdDevLifeExpectancy;
		this.averageCoutDeplacement=averageCoutDeplacement;
		this.stdDevcoutDeplacement=stdDevcoutDeplacement;
		Random rd = new Random();
    	double valueLifeExpectancy = rd.nextGaussian() * this.getStdDevLifeExpectancy()
    			+ this.getAverageLifeExpectancy();
    	this.setLifeExpectancy(valueLifeExpectancy);
    	double valuecoutDeplacement= rd.nextGaussian() * this.getStdDevCoutDeplacement()
    			+ this.getAverageCoutDeplacement();
    	this.setCoutDeplacement(valuecoutDeplacement);
    	this.setOrientation(rd.nextInt(4));//on se donne une orientation au hasard
    	this.setEnergie(rd.nextInt(500));//on se donne une quantité d'energie au hasard
    	this.setRapidite();// la rapidité se donne en fonction de la quantité d'energie recu par la cellule
	}
	/**
	 * cette méthode permet à la cellule de se deplacer selon sa situation (lente, mormale ou rapide)
	 */
	public void deplace(Univers univ){
		/*le cmportement de la cellule de type 2 est different de celui de la cellule de type 1*/
		if(this.type==2){
			this.deplace2(univ);
		}else{
			/*si la cellule peut cloner, elle clone
			 * une cellule attaquée par un virus ne peut pas cloner			 
			 */
			if (this.canClone(univ,this) && 
				!this.estAttaquee(univ, this.getAbscisse(), this.getOrdonnee())){
				this.Clone(univ);
			}else{//sinon, elle se deplace selon sa rapidité
				if (this.getRapidite()==2)this.deplace3fois(univ); 
				else if (this.getRapidite()==1) this.deplace1fois(univ);
				else if (this.getRapidite()==0) this.slowMove(univ);
				else System.out.println("Erreur de rapidité"+"r="+this.rapidite);
			}
		}
	}
	/**
	 * cette méthode permet à la cellule de se deplacer normalement
	 * la cellule se voit attaquée par un virus lorsqu'elle se trouve dans la meme case
	 *  que le virus ou bien si l'une de ses voisines est attaquée
	 */
	private void deplace1fois(Univers univ){
		this.setAge(this.getAge()+1);
		this.setRapidite();
		int[] coord=calculeCoordDeplacement(univ);//on recoit la prochaine case de cellule selon son orientation
		if (this.estCellule(univ, coord[0], coord[1])){
			if(sontDeux(univ, coord[0],coord[1])){//si sont deux le premier choix
				Random rd=new Random();
				int randomValue=rd.nextInt(coord.length);
				
				while(randomValue==0 || randomValue ==1) randomValue=rd.nextInt(coord.length);
				if (randomValue==2) {//si ne sont pas deux,  2e choix
					if (!this.sontDeux(univ, coord[randomValue], coord[randomValue+1])){
						this.setAbscisse(coord[randomValue]);
						this.setOrdonnee(coord[randomValue+1]);
						double cout=calculeCoutDeplacement();
						this.setCoutDeplacement(cout);
						this.setEnergie(this.getEnergie()-cout);
						this.mange(univ, coord[randomValue], coord[randomValue+1]);
						if (this.estVirus(univ, coord[randomValue], coord[randomValue+1])
							|| this.aVoisinAttaquee(univ)) this.attaqueVirus();
						this.changerOrientation();//une cellule deplace et change son orientation
					}else if (!this.sontDeux(univ, coord[randomValue+2], coord[randomValue+3])){
						this.setAbscisse(coord[randomValue+2]);
						this.setOrdonnee(coord[randomValue+3]);
						double cout=calculeCoutDeplacement();
						this.setCoutDeplacement(cout);
						this.setEnergie(this.getEnergie()-cout);
						this.mange(univ, coord[randomValue+2], coord[randomValue+3]);
						if (this.estVirus(univ, coord[randomValue+2], coord[randomValue+3])
							|| this.aVoisinAttaquee(univ)) this.attaqueVirus();
						this.changerOrientation();//une cellule deplace et change son orientation
					}else{
						this.mange(univ, this.getAbscisse(), this.getOrdonnee());
					}
				}else{//on fait un 3e choix
					if (!this.sontDeux(univ, coord[randomValue-1], coord[randomValue])){
						this.setAbscisse(coord[randomValue-1]);
						this.setOrdonnee(coord[randomValue]);
						double cout=calculeCoutDeplacement();
						this.setCoutDeplacement(cout);
						this.setEnergie(this.getEnergie()-cout);
						this.mange(univ, coord[randomValue-1], coord[randomValue]);
						if (this.estVirus(univ, coord[randomValue-1], coord[randomValue])
							|| this.aVoisinAttaquee(univ)) this.attaqueVirus();
						this.changerOrientation();//une cellule deplace et change son orientation
					}else if (!this.sontDeux(univ, coord[randomValue-3], coord[randomValue-2])){
						this.setAbscisse(coord[randomValue-3]);
						this.setOrdonnee(coord[randomValue-2]);
						double cout=calculeCoutDeplacement();
						this.setCoutDeplacement(cout);
						this.setEnergie(this.getEnergie()-cout);
						this.mange(univ, coord[randomValue-3], coord[randomValue-2]);
						if (this.estVirus(univ, coord[randomValue-3], coord[randomValue-2])
							|| this.aVoisinAttaquee(univ)) this.attaqueVirus();
						this.changerOrientation();//une cellule deplace et change son orientation
					}else{
						this.mange(univ, this.getAbscisse(), this.getOrdonnee());
					}
				}
			}else{
				this.setAbscisse(coord[0]);
				this.setOrdonnee(coord[1]);
				double cout=calculeCoutDeplacement();
				this.setCoutDeplacement(cout);
				this.setEnergie(this.getEnergie()-cout);
				this.mange(univ, coord[0], coord[1]);
				this.setZ(1);
				if (this.estVirus(univ, coord[0], coord[1])
					|| this.aVoisinAttaquee(univ)) this.attaqueVirus();
				this.changerOrientation();//une cellule deplace et change son orientation
			}
		}else{
			this.setAbscisse(coord[0]);
			this.setOrdonnee(coord[1]);
			double cout=calculeCoutDeplacement();
			this.setCoutDeplacement(cout);
			this.setEnergie(this.getEnergie()-cout);
			this.mange(univ, coord[0], coord[1]);
			this.setZ(0);
			if (this.estVirus(univ, coord[0], coord[1])
				|| this.aVoisinAttaquee(univ)) this.attaqueVirus();
			this.changerOrientation();//une cellule deplace et change son orientation
		}
		if (etat!=0) this.setEtat(this.getEtat()+1);
	}
	/**
	 * cette méthode permet à la cellule de deplacer 3fois plus vite que la mormale (appliquée pour les cellules rapides)
	 */
	private void deplace3fois(Univers univ){
		int i=0;
		while(i<3){
			deplace1fois(univ);
			i++;
		}
		this.setRapidite();
		this.setAge(this.getAge()-2);
		this.setEtat(this.getEtat()-2);
	}
	/**
	 * cette méthode fait ralentir le deplacement d'une cellule (appliquée pour les cellules mourantes)
	 */
	private void slowMove(Univers univ){
		double proba = Math.random();
		int[] coord=new int[6];
		this.setAge(this.getAge()+1);
		this.setRapidite();
		//on recoit la prochaine case de cellule selon son orientation
		coord=calculeCoordDeplacement(univ);
		/*la cellule a du mal a deplacé,*/
		if (proba > this.getEnergie()/100){
			this.setAbscisse(coord[0]);
			this.setOrdonnee(coord[1]);
			double cout=calculeCoutDeplacement();
			this.setCoutDeplacement(cout);
			this.setEnergie(this.getEnergie()-cout);
			this.mange(univ, coord[0], coord[1]);
			if (this.estVirus(univ, coord[0], coord[1]) || this.aVoisinAttaquee(univ))
				this.attaqueVirus();
			this.changerOrientation();//une cellule deplace et change son orientation
		}
	}
	/**
	 * cette méthode permet à la cellule d'acquérir de l'energie
	 */
	private void mange(Univers univ, int i, int j){
		if (this.estEnergie(univ, i,j) || 
			(this.estCellule(univ, i,j) && !sontDeux(univ,i,j))
			&& !estNull(univ,i,j) && !this.estVirus(univ, i, j)){
			double ener=univ.getMatNourriture()[i][j];
			if (this.getEnergie() < this.seuilAbondance){
				if (ener > 100){
					this.setEnergie(this.getEnergie()+100);
					ener=ener-100;
					univ.getMatNourriture()[i][j]=ener;
				}else{
					this.setEnergie(this.getEnergie()+ener);
					univ.getMatNourriture()[i][j]=0;
				}
			}
		}
	}
	/**
	 * cette méthode nous renvoie vrai si une case à deux cellules
	 */
	private boolean sontDeux(Univers univ,int i,int j){
		if (this.estCellule(univ, i, j)){
			Cellule cellule0=(Cellule) univ.getcMatrice()[i][j];
			for (Cellule[] tab: univ.cMatrice){
				for (Cellule cellule1: tab){
					if(cellule1 !=null && cellule1.getAbscisse()==cellule0.getAbscisse()
					   && cellule1.getOrdonnee()==cellule0.getOrdonnee()
					   && cellule1.getZ()!=cellule0.getZ())
					   return true;
				}
			}
		}
		return false;
	}
	
	private boolean estCellule(Univers univ, int i,int j){
		 return univ.getcMatrice()[i][j] instanceof Cellule && univ.getcMatrice()[i][j]!=null;
	}
	private boolean estEnergie(Univers univ, int i,int j){
		return univ.getMatNourriture()[i][j]>0;
	}
	private boolean estNull(Univers univ, int i,int j){
		return univ.getMatNourriture()[i][j]==0;
	}
	private boolean estVirus(Univers univ, int i,int j){
		return univ.getMatNourriture()[i][j]<0;
	}
	private void attaqueVirus(){
		this.setEtat(1);
	}
	private boolean estAttaquee(Univers univ, int i, int j){
		return univ.getcMatrice()[i][j].getEtat()>=1;
	}
	/**
	 * cette méthode permet de calculer le cout de deplacement d'une cellule
	 */
	private double calculeCoutDeplacement(){
		Random rd = new Random();
		double valuecoutDeplacement= rd.nextGaussian()*this.getStdDevCoutDeplacement()
				+this.getAverageCoutDeplacement();
    	this.setCoutDeplacement(valuecoutDeplacement);
    	return valuecoutDeplacement;
	}
	/**
	 * cette méthode retourne la case d'une cellule à la prochaine étape en prenant en compte 
	 * l'orientation de la cellule
	 */
	private int[] calculeCoordDeplacement(Univers univ){
		int[] coordCase=new int[2];
		int[] coordreste=new int[4];
		int [] temp=new int[6];
		boolean cas1=true,cas2=true,cas3=true;
		double proba=Math.random();
		if (this.orientation==0){//la cellule peut concerver son orientation
			if (searchByNext(univ)){
				if (proba<=this.PM[0]){
					coordCase[0]=this.getAbscisse()-1;
					coordCase[1]=this.getOrdonnee()+1;
					cas1=false;
				}else if (proba <=this.PM[0]+this.PM[1]){
					coordCase[0]=this.getAbscisse();
					coordCase[1]=this.getOrdonnee()+1;
					cas2=false;
				}else{
					coordCase[0]=this.getAbscisse()-1;
					coordCase[1]=this.getOrdonnee();
					cas3=false;
				}
				//pour recuperer les 2 autres cases des 3
				if (cas1 && cas2){
					coordreste[0]=this.getAbscisse()-1;
					coordreste[1]=this.getOrdonnee()+1;
					coordreste[2]=this.getAbscisse();
					coordreste[3]=this.getOrdonnee()+1;
				}
				if (cas1 && cas3){
					coordreste[0]=this.getAbscisse()-1;
					coordreste[1]=this.getOrdonnee()+1;
					coordreste[2]=this.getAbscisse()-1;
					coordreste[3]=this.getOrdonnee();
				}
				if (cas2 && cas3){
					coordreste[0]=this.getAbscisse()-1;
					coordreste[1]=this.getOrdonnee()+1;
					coordreste[2]=this.getAbscisse();
					coordreste[3]=this.getOrdonnee()+1;
				}
				
				for (int k=0;k<2;k++) temp[k]=coordCase[k];
				for (int k=2;k<6;k++) temp[k]=coordreste[k-2];
				
			}else{//la cellule change son orientation et récalcule ses coordonnees.
				this.changerOrientation();
				return calculeCoordDeplacement(univ);
			}
		}else if (this.orientation==1){
			if (searchByNext(univ)){
				if (proba<=0.5){
					coordCase[0]=this.getAbscisse()+1;
					coordCase[1]=this.getOrdonnee()+1;
					cas1=false;
				}else if (proba <=0.9){
					coordCase[0]=this.getAbscisse();
					coordCase[1]=this.getOrdonnee()+1;
					cas2=false;
				}else{
					coordCase[0]=this.getAbscisse()+1;
					coordCase[1]=this.getOrdonnee();
					cas3=false;
				}	
				
				if (cas1 && cas2){
					coordreste[0]=this.getAbscisse()+1;
					coordreste[1]=this.getOrdonnee()+1;
					coordreste[2]=this.getAbscisse();
					coordreste[3]=this.getOrdonnee()+1;
				}
				if (cas1 && cas3){
					coordreste[0]=this.getAbscisse()+1;
					coordreste[1]=this.getOrdonnee()+1;
					coordreste[2]=this.getAbscisse()+1;
					coordreste[3]=this.getOrdonnee();
				}
				if (cas2 && cas3){
					coordreste[0]=this.getAbscisse();
					coordreste[1]=this.getOrdonnee()+1;
					coordreste[2]=this.getAbscisse()+1;
					coordreste[3]=this.getOrdonnee();
				}
				for (int k=0;k<2;k++) temp[k]=coordCase[k];
				for (int k=2;k<6;k++) temp[k]=coordreste[k-2];
				
			}else{
				this.changerOrientation();
				return calculeCoordDeplacement(univ);
			}
		}else if (this.orientation==2){
			if (searchByNext(univ)){
				if (proba<=0.5){
					coordCase[0]=this.getAbscisse()-1;
					coordCase[1]=this.getOrdonnee()-1;
					cas1=false;
				}else if (proba <=0.9){
					coordCase[0]=this.getAbscisse();
					coordCase[1]=this.getOrdonnee()-1;
					cas2=false;
				}else{
					coordCase[0]=this.getAbscisse()-1;
					coordCase[1]=this.getOrdonnee();
					cas2=false;
				}
				
				if (cas1 && cas2){
					coordreste[0]=this.getAbscisse()-1;
					coordreste[1]=this.getOrdonnee()-1;
					coordreste[2]=this.getAbscisse();
					coordreste[3]=this.getOrdonnee()-1;
				}
				if (cas1 && cas3){
					coordreste[0]=this.getAbscisse()-1;
					coordreste[1]=this.getOrdonnee()-1;
					coordreste[2]=this.getAbscisse()-1;
					coordreste[3]=this.getOrdonnee();
				}
				if (cas2 && cas3){
					coordreste[0]=this.getAbscisse()-1;
					coordreste[1]=this.getOrdonnee();
					coordreste[2]=this.getAbscisse();
					coordreste[3]=this.getOrdonnee()-1;
				}
			
				for (int k=0;k<2;k++) temp[k]=coordCase[k];
				for (int k=2;k<6;k++) temp[k]=coordreste[k-2];
				
				
			}else{
				this.changerOrientation();
				return calculeCoordDeplacement(univ);
			}
		}else if (this.orientation==3){
			if (searchByNext(univ)){ 
				if (proba<=0.5){
					coordCase[0]=this.getAbscisse()+1;
					coordCase[1]=this.getOrdonnee()-1;
					cas1=false;
				}else if (proba <=0.9){
					coordCase[0]=this.getAbscisse();
					coordCase[1]=this.getOrdonnee()-1;
					cas2=true;
				}else{
					coordCase[0]=this.getAbscisse()+1;
					coordCase[1]=this.getOrdonnee();
					cas3=false;
				}	
				
				if (cas1 && cas2){
					coordreste[0]=this.getAbscisse()+1;
					coordreste[1]=this.getOrdonnee()-1;
					coordreste[2]=this.getAbscisse();
					coordreste[3]=this.getOrdonnee()-1;
				}
				if (cas1 && cas3){
					coordreste[0]=this.getAbscisse()+1;
					coordreste[1]=this.getOrdonnee()-1;
					coordreste[2]=this.getAbscisse()+1;
					coordreste[3]=this.getOrdonnee();
				}
				if (cas2 && cas3){
					coordreste[0]=this.getAbscisse();
					coordreste[1]=this.getOrdonnee()-1;
					coordreste[2]=this.getAbscisse()+1;
					coordreste[3]=this.getOrdonnee();
				}
				for (int k=0;k<2;k++) temp[k]=coordCase[k];
				for (int k=2;k<6;k++) temp[k]=coordreste[k-2];
			}else{
				this.changerOrientation();
				return calculeCoordDeplacement(univ);
			}
		}else System.out.println("Erreur d'orientation");
		return temp;
	}
	private void deplace2(Univers univ){
		int[] coord= coordDeplacement2(univ);
		this.mange(univ, coord[0], coord[1]);
		if (!this.sontDeux(univ, coord[0], coord[1])){
			this.setAbscisse(coord[0]);
			this.setOrdonnee(coord[1]);
			double cout=calculeCoutDeplacement();
			this.setCoutDeplacement(cout);
			this.setEnergie(this.getEnergie()-cout);
			this.mange(univ, coord[0], coord[1]);
			if (this.estVirus(univ, coord[0], coord[1])
				|| this.aVoisinAttaquee(univ)) this.attaqueVirus();
			this.changerOrientation();//une cellule deplace et change son orientation
		}
	}
	/**
	 * on renvoie les coordonnées de deplacement de la cellule de type2;
	 */
	private int[] coordDeplacement2(Univers univ){
		ArrayList<ArrayList<int[]>> coordDeplacement =calculeCoordDeplacement2(univ);
		if( coordDeplacement.get(0).size() == 0 && coordDeplacement.get(1).size() == 0 ){
			int[] coord=new int[2];
			coord[0]=this.getAbscisse();
			coord[1]=this.getOrdonnee();
			return coord;
		}else if(coordDeplacement.get(0).size() != 0){
			int[] coord=new int[2];
			Random rd = new Random();
			int random = rd.nextInt(coordDeplacement.get(0).size());
			coord[0]=coordDeplacement.get(0).get(random)[0];
			coord[1]=coordDeplacement.get(0).get(random)[1];
			return coord;
		}else{
			
			int[] coord=new int[2];
			Random rd = new Random();
			int random = rd.nextInt(coordDeplacement.get(1).size());
			coord[0]=coordDeplacement.get(1).get(random)[0];
			coord[1]=coordDeplacement.get(1).get(random)[1];
			return coord;
		}	
	}
	/**
	 * on calcule les coordonnées du deplacement de la cellule type2
	 */
	private ArrayList<ArrayList<int[]>> calculeCoordDeplacement2(Univers univ){
		ArrayList<ArrayList<int[]>> arrl=new ArrayList<ArrayList<int[]>>();
		ArrayList<int[]>arlEnergie=new ArrayList<int[]>();
		ArrayList<int[]>arlVide=new ArrayList<int[]>();
		for (int p=Math.max(this.getAbscisse()-1,0); p <= Math.min(this.getAbscisse()+1,
			univ.getDimension()-1);p++){
			for (int q=Math.max(this.getOrdonnee()-1,0); q <= Math.min(this.getOrdonnee()+1,
				univ.getDimension()-1);q++){
				if( univ.getMatNourriture()[p][q]>0){
					int[] coord=new int[2];
					coord[0]=p;
					coord[1]=q;
					arlEnergie.add(coord);
				}else if( univ.getMatNourriture()[p][q]==0){
					int[] coord=new int[2];
					coord[0]=p;
					coord[1]=q;
					arlVide.add(coord);
				}
			}
		}
		arrl.add(arlEnergie);
		arrl.add(arlVide);
		return arrl;			
	}
	/**
	 * cette méthode permet de verifier si une cellule peut continuer à conserver son orientation
	 * à la prochaine étape.
	 */
	private boolean searchByNext(Univers univ){
		if (this.orientation == 0) return this.getAbscisse()-1>=0 
				&& this.getOrdonnee()+1<univ.getDimension();
		else if (this.orientation ==1) return this.getAbscisse()+1<univ.getDimension() 
				&& this.getOrdonnee()+1<univ.getDimension();
		else if(this.orientation ==2) return (this.getAbscisse()-1>=0
				&& this.getOrdonnee()-1>=0);
		else if (this.orientation ==3) return this.getAbscisse()+1<univ.getDimension()
				&& this.getOrdonnee()-1>=0 ;
		else return false;	
	}
	/**
	 * cette méthode permet de changer l'orientation d'une cellule
	 */
	private void changerOrientation(){
		Random rd=new Random();
		int val=rd.nextInt(4);
		while(val==this.orientation) val=rd.nextInt(4);
		this.orientation=val;
	}
	/**
	 * cette méthode permet à la cellule de cloner
	 */
	
	public void Clone(Univers univ){
		int[] coordClonage = coordClonage(univ);
		if((coordClonage.length ==4)){//la cellule peut  cloner
			Random rd =new Random();
			//on prepare deux cellules filles
			Cellule cellule1=new Cellule(coordClonage[0], coordClonage[1],
					this.getAverageLifeExpectancy()+(int)rd.nextGaussian(),
					this.getStdDevCoutDeplacement()+(int)(rd.nextGaussian()),
					this.getAverageCoutDeplacement(),this.getStdDevCoutDeplacement());
			cellule1.setOrientation(rd.nextInt(4));//la cellule1 prend une orientation au hasard
			cellule1.setEnergie(this.getEnergie()/2);
			cellule1.setRapidite();
			cellule1.setPM(this);
			Cellule cellule2=new Cellule(coordClonage[2], coordClonage[3],
					this.getAverageLifeExpectancy()+(int)rd.nextGaussian(),
					this.getStdDevCoutDeplacement()+(int)(rd.nextGaussian()),
					this.getAverageCoutDeplacement(),this.getStdDevCoutDeplacement());
			cellule2.setOrientation(rd.nextInt(4));//la cellule2 prend une orientation au hasard
			cellule2.setEnergie(this.getEnergie()/2);
			cellule2.setRapidite();
			cellule2.setPM(this);
			univ.getcMatrice()[this.getAbscisse()][this.getOrdonnee()]=null;
			univ.getcMatrice()[coordClonage[0]][coordClonage[1]]=cellule1;
			univ.getcMatrice()[coordClonage[2]][coordClonage[3]]=cellule2;
			
			}
		}
	/**
	 * renvoie vrai si la cellule peut cloner.
	 */
	private boolean canClone(Univers univ,Cellule cellule){
		return this.searchByNext(univ)==true && cellule.getEnergie()> this.seuilClonage;	
	}
	/**
	 * cette méthode permet d'attribuer les PM de deplacement à une cellule fille
	 * tout en ajustant les PM pour qu'il n'y ait pas de PM negatives à cause de la deviation
	 */
	private void setPM(Cellule cellule){
		Random rd=new Random();
		int div=rd.nextInt(4);
		double rd1=Math.random(),rd2=Math.random();
		double deviation=0.1;
		while (rd1>deviation ) rd1 =Math.random();
		while (rd2>deviation ) rd2 =Math.random();
		if (rd2<=rd1){
			if(cellule.PM[0]+rd1<1 && cellule.PM[1]-rd1/(div+1)>=0
				&& cellule.PM[2]-div*(rd1/(div+1))>=0){
				this.PM[0]=cellule.PM[0]+rd1;
				this.PM[1]=cellule.PM[1]-rd1/(div+1);
				this.PM[2]=cellule.PM[2]-div*(rd1/(div+1));
			}else if(cellule.PM[1]+rd1<1 && cellule.PM[0]-rd1/(div+1)>=0
				&& cellule.PM[2]-div*(rd1/(div+1))>=0){
				this.PM[0]=cellule.PM[1]+rd1;
				this.PM[1]=cellule.PM[0]-rd1/(div+1);
				this.PM[2]=cellule.PM[2]-div*(rd1/(div+1));
			}else if(this.PM[2]+rd1<1 && cellule.PM[1]-rd1/(div+1)>=0
				&& cellule.PM[0]-div*(rd1/(div+1))>=0){
				this.PM[0]=cellule.PM[2]+rd1;
				this.PM[1]=cellule.PM[1]-rd1/(div+1);
				this.PM[2]=cellule.PM[0]-div*(rd1/(div+1));
			}else{
				this.PM[0]=cellule.PM[0];
				this.PM[1]=cellule.PM[1];
				this.PM[2]=cellule.PM[2];
			}
		}else{
			if(cellule.PM[0]-rd1>0 && cellule.PM[1]+rd1/(div+1)<1
				&& cellule.PM[2]+div*(rd1/(div+1))<1){
				this.PM[0]=cellule.PM[0]-rd1;
				this.PM[1]=cellule.PM[1]+rd1/(div+1);
				this.PM[2]=cellule.PM[2]+div*(rd1/(div+1));
			}else if(cellule.PM[1]-rd1>0 && cellule.PM[0]+rd1/(div+1)<1
				&& cellule.PM[2]+div*(rd1/(div+1))<1){
				this.PM[0]=cellule.PM[1]-rd1;
				this.PM[1]=cellule.PM[0]+rd1/(div+1);
				this.PM[2]=cellule.PM[2]+div*(rd1/(div+1));
			}else if(this.PM[2]-rd1>0 && cellule.PM[1]+rd1/(div+1)<1
				&& cellule.PM[0]+div*(rd1/(div+1))<1){
				this.PM[0]=cellule.PM[2]-rd1;
				this.PM[1]=cellule.PM[1]+rd1/(div+1);
				this.PM[2]=cellule.PM[0]+div*(rd1/(div+1));
			}else{
				this.PM[0]=cellule.PM[0];
				this.PM[1]=cellule.PM[1];
				this.PM[2]=cellule.PM[2];
			}
		}
	}
	/**
	 * cette méthode renvoie les coordonnées des deux cellules filles issues du clonage
	 */
	
	private int[] coordClonage(Univers univ){
			int[] coordDeplacementCellule = new int[8];
			int[] tmp=calculeCoordDeplacement(univ);
			int[] coordClonage=new int[4];
			for(int i=0; i<tmp.length; i++) coordDeplacementCellule[i]=tmp[i];
			coordDeplacementCellule[6]=this.getAbscisse();
			coordDeplacementCellule[7]=this.getOrdonnee();
			Random rand = new Random();
			int random1 = rand.nextInt(coordDeplacementCellule.length);
			int random2 = rand.nextInt(coordDeplacementCellule.length);
			while(random1 == random2 || (random1+1) == random2 || (random1-1) == random2)
				random2 = rand.nextInt(coordDeplacementCellule.length);
			if (random1%2==0){
				coordClonage[0]=coordDeplacementCellule[random1];
				coordClonage[1]=coordDeplacementCellule[random1+1];
			}else{
				coordClonage[0]=coordDeplacementCellule[random1-1];
				coordClonage[1]=coordDeplacementCellule[random1];
			}
			if (random2%2==0){
				coordClonage[2]=coordDeplacementCellule[random2];
				coordClonage[3]=coordDeplacementCellule[random2+1];
			}else{
				coordClonage[2]=coordDeplacementCellule[random2-1];
				coordClonage[3]=coordDeplacementCellule[random2];
			}
			return coordClonage;
	}
	/**
	 * cette méthode renvoie vrai si au moins une voisine de la cellule est attaquée
	 */
	private boolean aVoisinAttaquee(Univers univ){
		for (int p=Math.max(this.getAbscisse()-1,0); p <= Math.min(this.getAbscisse()+1,
			univ.getDimension()-1);p++){
			for (int q=Math.max(this.getOrdonnee()-1,0); q <= Math.min(this.getOrdonnee()+1,
				univ.getDimension()-1);q++){
				if (this.estCellule(univ, p, q) && this.estAttaquee(univ, p, q)) return true;
			}
		}
		return false;			
	}

	/**
	 * Accesseurs & mutateurs
	 */
	/**
	 * cette méthode determine la rapidité de la cellule en fonction de l'etat de son energie
	 */
	void setRapidite(){
		if(this.type==2){
			if (this.getEnergie()<=this.seuilStadeMort) this.rapidite=0;
			else  this.rapidite=1;
		}else if (this.type==1){
			if (this.getEnergie()>this.seuilAbondance) this.rapidite=2;
			else if (this.getEnergie()>this.seuilStadeMort 
				&& this.getEnergie()<this.seuilAbondance) 
				this.rapidite=1;
			else this.rapidite=0;
		}else System.out.println("Erreur de type!");
	}
	
	private double getAverageLifeExpectancy(){
		return this.averageLifeExpectancy;
	}
	private double getStdDevLifeExpectancy(){
		return this.stdDevLifeExpectancy;
	}
	private void setLifeExpectancy(Double lifeExpectancy){
		this.lifeExpectancy=lifeExpectancy;
	}
	public double getAverageCoutDeplacement(){
		return this.averageCoutDeplacement;
	}
	public  double getStdDevCoutDeplacement(){
		return this.stdDevcoutDeplacement;
	}
	private void setCoutDeplacement( double coutDeplacement){
		this.coutDeplacement=coutDeplacement;
	}
	protected void setOrdonnee(int ordonnee){
		this.ordonnee=ordonnee;
	}
	protected void setAbscisse(int abscisse){
		this.abscisse=abscisse;
	}
	int getEtat() {
		return this.etat;
	}
	void setEtat(int etat) {
		this.etat=etat;
	}
	int getAge() {
		return age;
	}
	void setAge(int age) {
		this.age = age;
	}
	int getAbscisse() {
		return abscisse;
	}
	int getOrdonnee() {
		return ordonnee;
	}
	int getZ() {
		return z;
	}
	void setZ(int z) {
		this.z = z;
	}
	int getRapidite(){
		return this.rapidite;
	}
	int getType() {
		return type;
	}
	void setType(int type) {
		this.type = type;
	}
	double getEnergie() {
		return energie;
	}
	void setEnergie(double energie) {
		this.energie = energie;
	}
	int getOrientation() {
		return orientation;
	}
	void setOrientation(int orientation) {
		this.orientation = orientation;
	}
}
