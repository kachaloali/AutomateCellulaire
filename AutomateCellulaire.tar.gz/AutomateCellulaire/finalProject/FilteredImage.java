package finalProject;
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
public class FilteredImage extends JPanel{
	private static final long serialVersionUID = 1L;
	Image img=null;
	Image imgFiltre=null;

  public FilteredImage(String Source){
    Toolkit kit=Toolkit.getDefaultToolkit();
    img=kit.getImage(Source);
    MediaTracker mt=new MediaTracker(this);
    imgFiltre=createImage(new FilteredImageSource(img.getSource(),new CropImageFilter(0,0,1000,225)));
    mt.addImage(imgFiltre,0);
    try{
      mt.waitForID(0);
    }catch(Exception ex){
    }
    setVisible(true);
    setSize(200,600);
  }

  public void paint(Graphics g){
    super.paint(g);
    g.drawImage(imgFiltre,10,-2,this);

  }
}
