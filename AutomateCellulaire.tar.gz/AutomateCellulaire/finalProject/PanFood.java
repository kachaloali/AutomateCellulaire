package finalProject;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class PanFood extends JPanel {
	private static final long serialVersionUID = 1L;
	Univers univ;
	
	PanFood(Univers univ){
		this.univ=univ;
	}
	
	public void paint(Graphics g){
		int cote=15, x=0, y=0;
		for (int i = 0 ; i <univ.getDimension(); i++){
			for (int j = 0 ; j < univ.getDimension(); j++){
				if (univ.getMatNourriture()[i][j]>0){
					g.setColor(Color.BLACK);
					g.fillRect(x,y,cote+6,cote+6);
					g.setColor(Color.blue);//energie
					g.fillRect(x+2,y+2,cote,cote);
				}else if (univ.getMatNourriture()[i][j]<0){
					g.setColor(Color.BLACK);
					g.fillRect(x,y,cote+6,cote+6);
					g.setColor(Color.pink);//Virus
					g.fillRect(x+2,y+2,cote,cote);
				}else{
					g.setColor(Color.BLACK);
					g.fillRect(x,y,cote+6,cote+6);
					g.setColor(Color.white);
					g.fillRect(x+2,y+2,cote,cote);
				}
				y=y+15;
			}
			y=0;
			x=x+15;	
		}	
	}

}
