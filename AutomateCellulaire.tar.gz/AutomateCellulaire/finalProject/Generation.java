package finalProject;
import java.io.FileWriter;
import java.io.IOException;
public class Generation {
	private Univers univ;
	FileWriter ftcell=new FileWriter("GenerationCellule.txt");
	FileWriter ftEnergie=new FileWriter("QuantiteEnergie.txt");
	Generation(Univers univ)throws IOException{
		this.univ=univ;
		ftcell.write("cellules saines	cellules attaquées\n");
		ftEnergie.write("Quantité energie\n");
	}
	/**
	 * cette méthode stocke une génération dans le fichier "GenerationCellule.txt"
	 */
	public void storeCellGeneration() throws IOException{
		try{
			calculeNbreCellule();
			ftcell.write(calculeNbreCellule()[0]+"\t"+calculeNbreCellule()[1]+"\n");
			}catch (Exception e){
				System.out.println(e.toString());
			}
	}
	/**
	 * cette méthode renvoie le nombre de cellule d'une génération
	 */
	private int[] calculeNbreCellule() throws IOException{
		int nbreCelluleNormale=0, nbreCelluleAttaquee=0;
		int[] tmp=new int[2];
		for (Cellule[] tab:this.univ.getcMatrice()){
			for (Cellule cell:tab){
				ftcell.write(" ");
				if (cell!=null){
					nbreCelluleNormale++;
					if(cell.getEtat()==1)
						nbreCelluleAttaquee++;
				}
				
				}
			}
	
		tmp[0]=nbreCelluleNormale;
		tmp[1]=nbreCelluleAttaquee;
		return tmp;
	}
	
	
	public void storeEnergie() throws IOException{
		try{
			ftEnergie.write("\n"+this.calculeQuantiteEnergie());
			}catch (Exception e){
				System.out.println(e.toString());
			}
	}
	/**
	 * cette méthode renvoie le nombre de cellule attaquées d'une génération
	 */
	private double calculeQuantiteEnergie() throws IOException{
		double quantite=0;
		for (double[] tab:this.univ.getMatNourriture()){
			for (double db:tab){
				ftEnergie.write(" ");
					if (db>0){
						quantite+=db;
						
					}
				}
			}
		return quantite;
	}
}
