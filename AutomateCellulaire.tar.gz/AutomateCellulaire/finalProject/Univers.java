package finalProject;
import java.awt.BorderLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSplitPane;

import finalClustering.Cluster;
import finalClustering.Clustering;
import finalClustering.Pm;
import finalClustering.convertIntoNewick;
public class Univers extends JFrame implements ActionListener{
	private static final long serialVersionUID = 1L;
	public Cellule[][] previouscMatrice;
	public Cellule[][] cMatrice;
	Cellule[][] nextcMatrice;
	public double[][] matNourriture;
	public Pannel pan;
	public PanFood pn;
	public int dimension;
	Generation gn;
	public double pcellule;
	public double pvirus;
	public double penergie;
	private JSplitPane split1,split2;
	private JPanel logo=new FilteredImage("images/University.png");
    ControlSpace esp;

    /**
     * constructeur
     */
	public  Univers(int dimension,double pcellule, double penergie, double pvirus) throws Exception{
		super("Automate Cellulaire");
		this.dimension=dimension;
		this.pcellule=pcellule;
		this.pvirus= pvirus;
		this.penergie=penergie;
		this.cMatrice=new Cellule[this.dimension][this.dimension];
		this.previouscMatrice=this.cMatrice;
		this.matNourriture=this.Environnement(dimension, penergie, pvirus);
		this.pan=new Pannel(this);
		this.pn=new PanFood(this);
		this.esp=new ControlSpace(this);
		this.setSize(dimension*15+222,dimension*15+260);
		//this.add(this.pn);
		split1= new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,pan,esp);
		split1.setDividerLocation(455);
		logo.setBounds(new Rectangle(50, 22, 1102, 2000));
		split2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,logo, split1);
		split2.setDividerLocation(210);
		this.getContentPane().add(split2, BorderLayout.CENTER);
		

		try{
			gn=new Generation(this);
			}catch (Exception e){
			System.out.println(e.toString());
			}
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	/**
	 * cette méthode permet de générer Matrice d'energie
	 */
	public double[][] Environnement(int dimension, double penergie,double pvirus){
		return this.genererNourriture(dimension, penergie,pvirus);
	}
	
	public Cellule[][] univCellule(int dimension,double p){
		return this.genererCellule(dimension,p);
	}
	
	private double[][] genererNourriture(int dim, double penergie, double pvirus){
		double[][] arl=new double[dim][dim];
		Random rd=new Random();
		for(int i = 0 ; i < dim ; i++){
			for(int j = 0 ; j < dim; j++){
				double randomValue = Math.random();
				if (randomValue <= penergie){
					arl[i][j]=rd.nextDouble()*500;
				}else if (randomValue<=1-pvirus){
					arl[i][j]=0;
				}else arl[i][j]=rd.nextDouble()*-1;
			}
		}
		return arl;	
	}

	/**
	 * cette méthode permet de générer aléatoirement des cellules
	 */
	private Cellule[][] genererCellule(int dim,double p){
		Cellule[][] arl=new Cellule[dim][dim];
		for(int i = 0 ; i < dim ; i++){
			for(int j = 0 ; j < dim; j++){
				double randomValue = Math.random();
				if (randomValue <= p){
					if(randomValue<p/2){
						arl[i][j]=new Cellule(i,j,12,10,2,4);
						arl[i][j].setType(1);
						arl[i][j].setRapidite();
					}else{
						arl[i][j]=new Cellule(i,j,12,10,2,4);
						arl[i][j].setType(2);
						arl[i][j].setRapidite();
					}
				}else arl[i][j]=null;					
			}
		}
		return arl;
	}
	/**
	 * cette méthode permet le deplacement des cellules
	 */
	void deplacement() throws IOException{
		int i=0;
		this.nextcMatrice=this.update();
		//si le bouton est yes est coché
		if (this.esp.yes.isSelected()){
			int sleep=300;
			while(esp.animated && this.hasCellule() ){
				try{
					Thread.sleep(sleep);
				}catch (InterruptedException ex){
					Thread.currentThread().interrupt();				
				}
				this.gn.storeCellGeneration();//=> permet de stocker toutes les générations dans un fichier.
				this.gn.storeEnergie();//=>les cellules attaquées par le virus
				/////////////////////////////////////////////////////////////////////////////////////////
				Random rd=new Random();
				double rd1=rd.nextInt(5),rd2=rd.nextInt(5);
				//on regenère la nouriture aléatoirement
				if (rd1==rd2) this.matNourriture=genererNourriture(this.dimension,Math.random(),Math.abs(rd1-rd2));//Math.abs(rd1-rd2)/100
				//on deplace plus rapidement quand la nourriture générée est bcp
				if(Math.abs(rd1-rd2)>=0.5) sleep-=20;
				else if(Math.abs(rd1-rd2)<0.2) sleep+=50;
				else sleep=300;
				if(sleep<50) sleep=50;
				/////////////////////////////////////////////////////////////////////////////////////////
				this.previouscMatrice=this.cMatrice;
				this.cMatrice=this.nextcMatrice;
				Cellule[][] tmp=this.update();
				this.nextcMatrice=this.balayer(tmp);			
				this.pan.repaint();
				this.makeClusters(i++);	
			}
			//si le bouton est no est coché pas de renouvellement de l'energie
		}else if (this.esp.no.isSelected()){
			while(esp.animated && this.hasCellule() ){
				try{
					Thread.sleep(500);
				}catch (InterruptedException ex){
					Thread.currentThread().interrupt();				
				}
				this.gn.storeCellGeneration();//=> permet de stocker toutes les générations dans un fichier.
				this.gn.storeEnergie();//=>les cellules attaquées par le virus
				this.previouscMatrice=this.cMatrice;
				this.cMatrice=this.nextcMatrice;
				Cellule[][] tmp=this.update();
				this.nextcMatrice=this.balayer(tmp);			
				this.pan.repaint();
				this.makeClusters(i++);
			}
		}else System.out.println("veuillez indiquer pour le renouvelement");
	
	}
	
	Cellule[][] update(){
		Cellule[][] tab=new Cellule[this.cMatrice.length][this.cMatrice.length];
		for (Cellule[] tmp: this.cMatrice){
			for (Cellule cellule: tmp){
				if(cellule !=null) {
					cellule.deplace(this);
					tab[cellule.getAbscisse()][cellule.getOrdonnee()]=cellule;
				}
			}	
		}
		return tab;
	}
	/**
	 * cette méthode permet de degager les cellules mortes de la grille
	 */
	private Cellule[][] balayer(Cellule[][] matrice ){
		int i=0,j=0;
		for (Cellule[] tab: matrice){
			for (Cellule cellule: tab){
					if(cellule !=null && (cellule.getEnergie()<=0 || cellule.getEtat()==5))
						matrice[cellule.getAbscisse()][cellule.getOrdonnee()]=null;
					else if (cellule !=null && cellule.getEnergie()>0)
						matrice[cellule.getAbscisse()][cellule.getOrdonnee()]=cellule;
					else matrice[i][j]=null;
				j++;
			}
			j=0;
			i++;
		}
		return matrice;
	}
	/**
	 * cette méthode test si l'Univers des cellules est vide ou pas
	 */
	boolean hasCellule(){
		for (Cellule[] tab: this.cMatrice){
			for (Cellule  cellule: tab){
				if(cellule !=null) {	
					return true;
				}
			}	
		}
		return false;
	}
	/**
	 * cette métode calule les clusters et les affiche
	 */
	public void makeClusters(int i){
		/////////////////////////////////////////////////////////////////////////////////////////
		if(!esp.tcluster.getText().equalsIgnoreCase("")){
			esp.numGeneration=(int) Double.parseDouble(esp.tcluster.getText());
			if(!esp.tnumberOfCluster.getText().equalsIgnoreCase(""))
				esp.numberOfClusters=(int) Double.parseDouble(esp.tnumberOfCluster.getText());
			else esp.numberOfClusters=0;
		}else esp.numGeneration=0;
		/////////////////////////////////////////////////////////////////////////////////////////
		//on calule le cluster de la generation esp.numGeneration
		if (esp.numGeneration!=0 && i==esp.numGeneration){
			System.out.println("Total des cellules: "+getPM().size());
			Clustering cl=new Clustering();
			cl.setClustersPM(this.getPM());
			cl.setClusters(this.getClusterPM());
			if(esp.numberOfClusters!=0){
				cl.setK(esp.numberOfClusters);
				cl.calculate();
			}else System.out.println("Nombre de cluster est null!");
			
			/////////////////////////////////////////////////////////////////////////////////////////
			convertIntoNewick cn=new convertIntoNewick();
			System.out.println("conversion en format newick:"+cl.clusters.size());
			System.out.println(cn.getNewick(cl.clusters));
			////////////////////////////////////////////////////////////////////////////////////////
			
		}
	
	}
    /**
     * cette méthode renvoie un tableau de clusters, chaque cluster a un seul élément(PM)
     */
    ArrayList<Cluster> getClusterPM(){
    	int i=0;
		ArrayList<Cluster> arl=new ArrayList<Cluster>();
		for (Cellule[] tab: this.getcMatrice()){
			for (Cellule  cellule: tab){
				if (cellule != null){
					i+=1;
					Cluster cluster = new Cluster(i);
		    		cluster.setCentre(new Pm(cellule.PM[0],cellule.PM[1],cellule.PM[2]));
		    		arl.add(cluster);
				}
			}
		}
		return arl;
	}
    /**
     * cette méthode renvoie les PM de toutes les cellules de l'univers
     */
    ArrayList<Pm> getPM(){
		ArrayList<Pm> arl=new ArrayList<Pm>();
		for (Cellule[] tab: this.getcMatrice()){
			for (Cellule  cellule: tab){
				if (cellule != null){
					Pm pm=new Pm(cellule.PM[0],cellule.PM[1],cellule.PM[2]);
		    		arl.add(pm);
				}
			}
		}
		return arl;
	}
	/**
	 * Accesseurs & Setteurs
	 */
	Cellule[][] getcMatrice() {
		return cMatrice;
	}
	void setcMatrice(Cellule[][] cMatrice) {
		this.cMatrice = cMatrice;
	}
	public int getDimension() {
		return dimension;
	}
	void setDimension(int dim) {
		this.dimension = dim;
	}
	double[][] getMatNourriture() {
		return matNourriture;
	}
	void setMatNourriture(double[][] matNourriture) {
		this.matNourriture = matNourriture;
	}	
	/**
	 * Gestion des evenements
	 */
	public void actionPerformed(ActionEvent arg0) {
			esp.actionPerformed(arg0);
	}
	/**
	 * Méthode principale
	 */
	public static void main(String[] args){
		try{
			new Univers(30,0.1, 0.01,0.0);	
		}catch (Exception e){
			System.out.println(e.toString());
		}
	}
}
	
