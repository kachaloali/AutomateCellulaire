package finalProject;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import javax.swing.JPanel;

public class Pannel extends JPanel {
	private static final long serialVersionUID = 1L;
	Univers univ;
	GridBagConstraints gc;
	/**
	 * constructeur
	 */
	Pannel(Univers univ){
		this.univ=univ;
	}
	
	public void paint(Graphics g){
		int cote=15, x=0, y=0;
		for (int i = 0 ; i <univ.getDimension(); i++){
			for (int j = 0 ; j < univ.getDimension(); j++){
				if (univ.cMatrice[j][i]!=null){
					if(univ.cMatrice[j][i].getEtat()>=1){
						g.setColor(Color.BLACK);
						g.fillRect(x,y,cote+6,cote+6);
						g.setColor(Color.red);//cellule attaquée par un virus
						g.fillRect(x+2,y+2,cote,cote);
					}else if(univ.cMatrice[j][i].getType()==1){
						if (univ.cMatrice[j][i].getRapidite()==2){
							g.setColor(Color.BLACK);
							g.fillRect(x,y,cote+6,cote+6);
							g.setColor(Color.orange); //cellule bien portante en abondance d'energie
							g.fillRect(x+2,y+2,cote,cote);
						}else if (univ.cMatrice[j][i].getRapidite()==1){
							g.setColor(Color.BLACK);
							g.fillRect(x,y,cote+6,cote+6);
							g.setColor(Color.green); //cellule bien portante normale
							g.fillRect(x+2,y+2,cote,cote);
						}else if (univ.cMatrice[j][i].getRapidite()==0){
							g.setColor(Color.BLACK);
							g.fillRect(x,y,cote+6,cote+6);
							g.setColor(Color.GRAY);  //cellule mourante un peu lente
							g.fillRect(x+2,y+2,cote,cote);
						}else System.out.println("Erreur de rapidité!");
					}else{
						if (univ.cMatrice[j][i].getRapidite()==1){
							g.setColor(Color.BLACK);
							g.fillRect(x,y,cote+6,cote+6);
							g.setColor(Color.blue); //cellule bien portante normal
							g.fillRect(x+2,y+2,cote,cote);
						}else if (univ.cMatrice[j][i].getRapidite()==0){
							g.setColor(Color.BLACK);
							g.fillRect(x,y,cote+6,cote+6);
							g.setColor(Color.GRAY); //cellule mourante un peu lente 
							g.fillRect(x+2,y+2,cote,cote);
						}else System.out.println("Erreur de rapidité!");
					}
				}else{
					g.setColor(Color.BLACK);
					g.fillRect(x,y,cote+6,cote+6);
					g.setColor(Color.white);
					g.fillRect(x+2,y+2,cote,cote);
				}
				y=y+15;
			}
			y=0;
			x=x+15;	
		}	
	}

}
